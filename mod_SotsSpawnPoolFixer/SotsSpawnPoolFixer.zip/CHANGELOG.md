## Changelog:
```
v1.3.1
No longer removes NoCeiling flag, just fixes the wrong NodeGraphs.
-It is a issue really only for Sanctuary.

v1.3.0
Made VillageNight use Village interactables DccsPool (Does not have it's own)(Instead of GolemPlains with fixed RadarScanner)
ReAdded SotV enemy removals that were lost when DCCS blender was made
Seers no longer show pre loop variants after looping.
New issue found : Distant Roost and Scorched Acres can't spawn DLC1 interactables (fixed)
Removed NoCeiling tag from LunarChest & Halcyon Shrine



v1.2.0
Removed most of the mod as it was unneeded due to rework of the DCCS DLC system.
Fixed multiple logs not being obtainable, either still or now due to new issues.

v1.1.1
Removed fix for Roost2 and Wetland never using DLC pools. (Added in 1.3.6)
Removed fix for Golden Dieback using Treeborn spawn pool pools. (Added in 1.3.6)
Removed fix for Bulwark Variant log using inccorect name. (Added in 1.3.6)
Removed fix for Bulwarks variants not giving correct logs. (Added in 1.3.5)

v1.1.0
Fixed Bulwark Ambry variants having the wrong logbook unlocks set.
(Bit overdue, but then again game shoulda updated by now)

v1.0.2 - Lowered weights in LoopStage1 stage pool. (Forgot)
v1.0.1 -
Lowered Titanic Plains and Distant Roost weight to 0.75. 
-(Normally: Both variants have a weight of 1, making them more common than other stage 1s.)
-(The variants are quite different tho so making them 0.5 seems a bit much)
Fixed Sanctuary not using its DLC2 Monster pool. (Has no differences, idk why this file exists)


v1.0.0 -Release