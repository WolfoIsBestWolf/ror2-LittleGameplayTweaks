Wish Seekers of the Storm had more loop variants so I tried my hand at it.

Config to make them and official variants happen pre-loop.\
Or make them chance based on loops.\
You can turn off individual variants if you dislike them.

The loop variants are meant to have enemy changes, but this will remain part of [LittleGameplayTweaks](https://thunderstore.io/package/Wolfo/LittleGameplayTweaks/).\
Viscious Falls and Disturbed Impact won't have Elder Lemurians or Void Reavers on stage 1.\
Variants might still have some gamelplay differences. (Such as the slowing tar river on Aquaduct)

No idea how this mod interacts with Stage Aesthetics or Cooler Stages.

<details>
  <summary>Weather changes ingame</summary>
  
![Missing Immage](https://raw.githubusercontent.com/WolfoIsBestWolf/ror2-LittleGameplayTweaks/main/modPageImages/ltgStages.png)


#### Inspirations :
Titanic Plains : Trailer Version\
Siphoned Forest : aurora Borealis are kinda cool  \
Abandoned Aqueduct : Unused Tar River\
Wetland Aspect : Internal name FoggySwamp  \
Scorched Acres : Unused Eclipse Weather (they just tested it here for the menu for some reason)\
Sulfur Pools : Real Blue "Lava" Volcanos (Not implemented)\
Abyssal Depths : Vague Red Plane / Void themeing\
Sundered Grove : Spring/Autumn/Golden Dieback (TBD, Not implemented)\
Helminth Hatchery : Molten Gold

</details>
 

 

##
 
Report bugs to @Wolfo.wolfo in the Risk of Rain 2 discord or RoR2 Modding discord.\
If you're reporting a bug that isn't something obvious include the log file.

 