## Changelog:
```
v1.1.0
Added loop weather for Wetlands Aspect (Foggy, Rainy, More Water)

Hopefully increased consistency of syncing weathers in multiplayer.
Fixed Golden Dieback not appearing pre loop if enabled.
Fixed stage names still changing if variant disabled.
If stage order is random (Artifact of Wander), 50/50 chance to use the loop or preloop chance.

-Stage 1 Disturbed Impact will no longer have.
--Elder Lemurian
-Stage 1 Viscious Falls will no longer have.
--Elder Lemurians
--Void Reavers
--Imp Overlords
--Grandparents



v1.0.3 Left debug multiplayer testing on whoops.
v1.0.2
Added config to enable variants on specific stages.
Added config to enable Goo River on Aquaduct alt weather
Variants should now be synced in Multiplayer

1,0.1 
Fixed some issues in the config and how it was applied.

1.0.0 - Now seperate mod
Added loop weather for Siphoned Forest (Aurora)
Added loop weather for Abandoned Aquaduct (Tar, Green)
Added loop weather for Abyssal Depths (Magenta)
Added loop weather for Helminth Hatchery (Gold)

0.9.0
Added loop weather for Titanic Plains (Sunset)
Added loop weather for Scorched Acres (Dusk)