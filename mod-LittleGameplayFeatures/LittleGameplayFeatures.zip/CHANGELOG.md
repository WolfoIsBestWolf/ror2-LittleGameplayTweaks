## Changelog:
```
v3.5.3
Fixed language file being outdated.
Fixed Prism run disable config not actually working.

v3.5.2
Changed way RedMultiShop is added to spawn pools so they no longer show up in Void Locust

v3.5.1 : Typo
v3.5.0
Split off from main mod.

Prismatic Run now it's own game mode instead of a rule for Prismatic Trials



```