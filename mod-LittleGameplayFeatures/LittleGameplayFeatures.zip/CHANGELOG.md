## Changelog:
```
v3.5.1 : Typo
v3.5.0
Split off from main mod.

Prismatic Run now it's own game mode instead of a rule for Prismatic Trials



```